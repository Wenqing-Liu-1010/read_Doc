#!/bin/bash
echo "Running $0 on host $(hostname), GPU=$CUDA_VISIBLE_DEVICES"

cd /capstor/scratch/cscs/wliu/Spatio-Temporal-Non-Parametric-Hawkes/STPP

for fit_seed in 50 51 52 53; do
  for M_mu in 3; do
    for M_phi in 3; do
    echo "Fit_seed=$fit_seed, M_mu=$M_mu, M_phi=$M_phi"
    python /capstor/scratch/cscs/wliu/Spatio-Temporal-Non-Parametric-Hawkes/STPP/additive_rbf.py \
      --n_sequences 1 \
      --mode parametric \
      --link_function exp \
      --random_seed 32 \
      --fit_seed $fit_seed \
      --n_inducing_points_mu $M_mu \
      --n_inducing_points_phi $M_phi \
      --num_steps 20000 \
      --vi_samples 1000 \
      --T_max 10.0 \
      --X_max 10.0 \
      --Y_max 10.0 \
      --T_phi 0.5 \
      --X_phi 0.3 \
      --Y_phi 0.3
    done
  done
done

